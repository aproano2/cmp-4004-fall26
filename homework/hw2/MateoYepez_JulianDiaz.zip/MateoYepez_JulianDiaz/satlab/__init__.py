"""Reproducible SAT formalization experiment."""
